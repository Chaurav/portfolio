# Sourav Surya Majumder — Stylish Portfolio (React + Vite + Tailwind)

This repo is ready for **zero local build**. Connect it to **Netlify** or **Vercel** and they will build & host automatically.

## Deploy on Netlify
1. Push this folder to a new GitHub repo (or create in GitHub and upload files).
2. Go to https://app.netlify.com → Add new site → Import from Git.
3. Select your repo.
4. Build command: `npm run build`  | Publish directory: `dist`
5. Deploy.

## Deploy on Vercel
1. Push to GitHub.
2. Go to https://vercel.com → Add New… → Project → Import your repo.
3. Framework preset: **Vite** (auto-detected).
4. Build command: `npm run build`  | Output: `dist`
5. Deploy.

## Notes
- Your CV is included at `/Sourav_Surya_Majumder_CV.docx` and `/public/Sourav_Surya_Majumder_CV.docx`.
- The UI components live at `src/components/ui/*` and mimic shadcn API so the code works without extra setup.
