import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Mail, Phone, MapPin, Download, Github, Linkedin, Globe, GraduationCap, Briefcase, Mic2, Users } from 'lucide-react'

const NAV = [
  { id: 'about', label: 'About' },
  { id: 'education', label: 'Education' },
  { id: 'research', label: 'Research & Experience' },
  { id: 'talks', label: 'Talks' },
  { id: 'activities', label: 'Activities' },
  { id: 'skills', label: 'Skills' },
  { id: 'contact', label: 'Contact' },
]

function Section({ children }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}
      className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
      {children}
    </motion.div>
  )
}

function Header({ current, setCurrent }) {
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-white/70 dark:bg-neutral-950/70 border-b border-neutral-200 dark:border-neutral-800">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-indigo-500 via-sky-500 to-cyan-400" />
          <div>
            <h1 className="text-lg font-semibold tracking-tight">Sourav Surya Majumder</h1>
            <p className="text-xs text-neutral-600 dark:text-neutral-400">Data Science & AI • Geometric Data Science • Materials Informatics</p>
          </div>
        </div>
        <nav className="hidden md:flex gap-2">
          {NAV.map((n) => (
            <Button key={n.id} variant={current === n.id ? 'default' : 'ghost'} className="rounded-2xl" onClick={() => setCurrent(n.id)}>
              {n.label}
            </Button>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <a href="mailto:souravsurya1998@gmail.com" className="hidden sm:inline-flex">
            <Button variant="outline" className="rounded-2xl"><Mail className="mr-2 h-4 w-4"/>Email</Button>
          </a>
          <a href="/Sourav_Surya_Majumder_CV.docx">
            <Button className="rounded-2xl"><Download className="mr-2 h-4 w-4"/>CV</Button>
          </a>
        </div>
      </div>
      <div className="md:hidden border-t border-neutral-200 dark:border-neutral-800 px-2 py-2 overflow-x-auto">
        <div className="flex gap-2 w-max">
          {NAV.map((n) => (
            <Button key={n.id} size="sm" variant={current === n.id ? 'default' : 'ghost'} className="rounded-2xl" onClick={() => setCurrent(n.id)}>
              {n.label}
            </Button>
          ))}
        </div>
      </div>
    </header>
  )
}

function Hero({ setCurrent }) {
  return (
    <Section>
      <div className="grid md:grid-cols-[1.2fr_.8fr] gap-6 items-center">
        <div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">Hello — I’m Sourav.</h2>
          <p className="mt-3 text-neutral-700 dark:text-neutral-300 leading-relaxed">
            I’m a researcher in <strong>Geometric Data Science</strong> and <strong>AI</strong>, working on
            robust descriptors and symmetry analysis for large-scale crystal datasets. I enjoy building
            reliable pipelines and visual analytics for materials discovery.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Badge>Research Collaborator — University of Liverpool</Badge>
            <Badge variant="secondary">MSc Data Science & AI — Distinction</Badge>
            <Badge variant="outline">Kolkata, India</Badge>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button className="rounded-2xl" onClick={() => setCurrent('research')}><Briefcase className="mr-2 h-4 w-4"/>See my work</Button>
            <Button variant="outline" className="rounded-2xl" onClick={() => setCurrent('talks')}><Mic2 className="mr-2 h-4 w-4"/>Talks</Button>
            <Button variant="ghost" className="rounded-2xl" onClick={() => setCurrent('contact')}><Mail className="mr-2 h-4 w-4"/>Contact</Button>
          </div>
        </div>
        <Card className="rounded-3xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><GraduationCap className="h-5 w-5"/>At a glance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex items-start gap-3">
              <div className="mt-1 h-2.5 w-2.5 rounded-full bg-indigo-500" />
              <p><strong>MSc in Data Science & AI</strong>, University of Liverpool (2023–2024) — <em>Distinction</em>.</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="mt-1 h-2.5 w-2.5 rounded-full bg-sky-500" />
              <p><strong>MSc in Applied Mathematics</strong>, Sister Nivedita University (2021–2023) — CGPA 9.02/10.</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="mt-1 h-2.5 w-2.5 rounded-full bg-cyan-500" />
              <p><strong>BSc in Mathematics</strong>, University of Calcutta (2018–2021).</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </Section>
  )
}

function Education() {
  return (
    <Section>
      <h2 className="text-2xl font-semibold tracking-tight mb-4">Education</h2>
      <div className="grid gap-4">
        <Card className="rounded-3xl">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>University of Liverpool — MSc in Data Science & AI</span>
              <Badge className="ml-2">2023–2024</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p><strong>Classification:</strong> Distinction</p>
            <p><strong>Coursework:</strong> Research Methods; Database & Information Systems; Programming Fundamentals; Maths & Stats for DS & AI; Computational Intelligence; Machine Learning & Bioinspired Optimisation; Applied AI; Data Mining & Visualisation; MSc Project.</p>
          </CardContent>
        </Card>
        <Card className="rounded-3xl">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Sister Nivedita University — MSc in Applied Mathematics</span>
              <Badge className="ml-2">2021–2023</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p><strong>CGPA:</strong> 9.02/10</p>
            <p><strong>Coursework:</strong> Discrete Mathematics; Graph Theory & Non-linear Dynamics; Numerical Analysis; Integral Transforms & Integral Equations; Python Programming; MIS; Cryptography & Network Security; Optimisation & OR; Machine Learning; Financial Mathematics; Bio-mathematics.</p>
          </CardContent>
        </Card>
        <Card className="rounded-3xl">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>University of Calcutta — BSc in Mathematics</span>
              <Badge className="ml-2">2018–2021</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm">
            <p>Coursework included Calculus; Geometry & Vector Analysis; ODE/PDE & Multivariate Calculus; C Programming; Scientific Computing with SageMath & R; Probability & Statistics; Linear Programming & Game Theory; Numerical Methods.</p>
          </CardContent>
        </Card>
      </div>
    </Section>
  )
}

function Research() {
  return (
    <Section>
      <h2 className="text-2xl font-semibold tracking-tight mb-4">Research & Experience</h2>
      <Card className="rounded-3xl">
        <CardHeader>
          <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <span>Research Collaborator — Data Science Theory & Applications Group, University of Liverpool</span>
            <Badge>June 2023 – Present</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p><strong>Supervisor:</strong> Professor Vitaliy Kurlin</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>Developed and computed geometric descriptors for 50,000+ experimental & predicted crystal structures using Python and custom scientific packages.</li>
            <li>Automated symmetry analysis using distance metrics to assess structural deviations.</li>
            <li>Processed multi-structure simulated CIF datasets (T0, T1, T2, T2E) to extract atomic & molecular features; optimised parsing for large-scale input.</li>
            <li>Processed and analysed 1017 simulated landscapes and 1M+ simulated molecular crystal structures.</li>
            <li>Generated statistics and visual plots correlating asymmetry measures with density, energy, packing efficiency, and distance metrics.</li>
            <li>Contributed to research output for peer‑reviewed publication on geometric properties of synthesiseable crystals.</li>
          </ul>
        </CardContent>
      </Card>
    </Section>
  )
}

function Talks() {
  return (
    <Section>
      <h2 className="text-2xl font-semibold tracking-tight mb-4">Conferences & Invited Talks</h2>
      <Card className="rounded-3xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Mic2 className="h-5 w-5"/>MACSMIN 2025 — Mathematics & Computer Science for Materials Innovation</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-2">
          <p><strong>Talk:</strong> Quantifying Continuous Asymmetry with Isometry Invariants</p>
          <p><strong>When/Where:</strong> 9–12 September 2025, University of Liverpool, UK (Hybrid)</p>
          <p>Satellite event of the 35th European Crystallographic Meeting (ECM35), Poznań, Poland. Organised by Professor Vitaliy Kurlin’s group and funded by the LMS through the Applied Geometry & Topology network.</p>
        </CardContent>
      </Card>
    </Section>
  )
}

function Activities() {
  return (
    <Section>
      <h2 className="text-2xl font-semibold tracking-tight mb-4">Voluntary & Professional Activities</h2>
      <div className="grid gap-4">
        <Card className="rounded-3xl">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Course Coordinator — University of Liverpool</span>
              <Badge>Sep 2023 – Sep 2024</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm space-y-2">
            <ul className="list-disc pl-5 space-y-1">
              <li>Represented academic & welfare concerns of 400+ MSc students in SSLC meetings.</li>
              <li>Compiled structured feedback across 8+ modules; presented reports enabling 3 departmental teaching improvements.</li>
              <li>Collaborated with course coordinators and school reps to enhance course delivery & assessment flexibility.</li>
              <li>Advocated for increased teaching time in Programming Fundamentals leading to a 50% boost in hours.</li>
              <li>Strengthened student–staff communication for transparency and accountability.</li>
            </ul>
          </CardContent>
        </Card>
        <Card className="rounded-3xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Users className="h-5 w-5"/>MIF++ Seminar Participant — Materials Innovation Factory</CardTitle>
          </CardHeader>
          <CardContent className="text-sm">
            <p>Attend interdisciplinary seminars and research talks on advanced materials design, automation, and data‑driven discovery; engage with topics in computational materials science, machine learning for chemistry, and high‑throughput experimentation.</p>
          </CardContent>
        </Card>
      </div>
    </Section>
  )
}

function Skills() {
  return (
    <Section>
      <h2 className="text-2xl font-semibold tracking-tight mb-4">Skills & Interests</h2>
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="rounded-3xl">
          <CardHeader><CardTitle>Technical</CardTitle></CardHeader>
          <CardContent className="text-sm">
            <div className="flex flex-wrap gap-2">
              {['Python','NumPy','SciPy','pandas','matplotlib','scikit-learn','scikit-optimize','PyG','Reinforcement Learning','CCDC Python API','CIF processing','SQL','LaTeX','Git','MS Office'].map(s => (
                <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-3xl">
          <CardHeader><CardTitle>Computational Expertise</CardTitle></CardHeader>
          <CardContent className="text-sm">
            <div className="flex flex-wrap gap-2">
              {['Geometric invariants','Symmetry analysis','Clustering','Data visualisation'].map(s => (
                <Badge key={s} className="text-xs">{s}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-3xl">
          <CardHeader><CardTitle>Languages</CardTitle></CardHeader>
          <CardContent className="text-sm">
            <div className="flex flex-wrap gap-2">
              {['Bengali (native)','English (fluent)','Hindi (conversational)','French (basic)'].map(s => (
                <Badge key={s} variant="outline" className="text-xs">{s}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-3xl">
          <CardHeader><CardTitle>Interests</CardTitle></CardHeader>
          <CardContent className="text-sm">
            <div className="flex flex-wrap gap-2">
              {['Geometric data science','Machine learning & AI','Photography','Literature'].map(s => (
                <Badge key={s} variant="outline" className="text-xs">{s}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </Section>
  )
}

function About() {
  return (
    <Section>
      <h2 className="text-2xl font-semibold tracking-tight mb-4">About</h2>
      <div className="grid md:grid-cols-[1.2fr_.8fr] gap-6">
        <div className="space-y-3 text-neutral-700 dark:text-neutral-300">
          <p>
            I build data‑driven methods for analysing periodic structures and quantifying symmetry, with a
            focus on descriptors that are robust, scalable, and informative for materials design. My recent
            work involves processing <strong>50k+</strong> crystal structures and <strong>1M+</strong> simulated molecular crystals,
            extracting atomic/molecular features and correlating asymmetry with physical properties.
          </p>
          <p>
            I value clarity, reproducibility, and practical impact — whether optimising parsers for large CIF datasets
            or designing analysis pipelines that others can rely on.
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            <Badge variant="secondary">Geometric Data Science</Badge>
            <Badge variant="secondary">Materials Informatics</Badge>
            <Badge variant="secondary">Machine Learning</Badge>
          </div>
        </div>
        <Card className="rounded-3xl">
          <CardHeader><CardTitle>Quick Facts</CardTitle></CardHeader>
          <CardContent className="text-sm space-y-2">
            <div className="flex items-center gap-2"><MapPin className="h-4 w-4"/>Sonarpur, Kolkata, India</div>
            <div className="flex items-center gap-2"><Mail className="h-4 w-4"/>souravsurya1998@gmail.com</div>
            <div className="flex items-center gap-2"><Phone className="h-4 w-4"/>+91‑8276069386</div>
          </CardContent>
        </Card>
      </div>
    </Section>
  )
}

function Contact() {
  return (
    <Section>
      <h2 className="text-2xl font-semibold tracking-tight mb-4">Contact</h2>
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="rounded-3xl">
          <CardHeader><CardTitle>Get in touch</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <p>If you’d like to discuss research or collaboration, email works best.</p>
            <div className="flex flex-col gap-2">
              <a className="inline-flex items-center gap-2" href="mailto:souravsurya1998@gmail.com"><Mail className="h-4 w-4"/>souravsurya1998@gmail.com</a>
              <a className="inline-flex items-center gap-2" href="tel:+918276069386"><Phone className="h-4 w-4"/>+91‑8276069386</a>
              <span className="inline-flex items-center gap-2"><MapPin className="h-4 w-4"/>Sonarpur, Kolkata, India</span>
            </div>
            <div className="flex gap-2 pt-1">
              <Button variant="outline" className="rounded-2xl"><Github className="mr-2 h-4 w-4"/>GitHub</Button>
              <Button variant="outline" className="rounded-2xl"><Linkedin className="mr-2 h-4 w-4"/>LinkedIn</Button>
              <Button variant="outline" className="rounded-2xl"><Globe className="mr-2 h-4 w-4"/>Google Scholar</Button>
            </div>
          </CardContent>
        </Card>
        <Card id="download-cv" className="rounded-3xl">
          <CardHeader><CardTitle>Download CV</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <p>You can download a copy of my CV here.</p>
            <a href="/Sourav_Surya_Majumder_CV.docx" className="inline-flex" title="Download CV">
              <Button className="rounded-2xl"><Download className="mr-2 h-4 w-4"/>Download .docx</Button>
            </a>
            <p className="text-xs text-neutral-600 dark:text-neutral-400">Place the file in the project root or public/ so the link works on Netlify/Vercel.</p>
          </CardContent>
        </Card>
      </div>
    </Section>
  )
}

export default function Portfolio() {
  const [current, setCurrent] = useState('about')
  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100">
      <Header current={current} setCurrent={setCurrent} />
      {current === 'about' && (<><Hero setCurrent={setCurrent} /><About /></>)}
      {current === 'education' && <Education />}
      {current === 'research' && <Research />}
      {current === 'talks' && <Talks />}
      {current === 'activities' && <Activities />}
      {current === 'skills' && <Skills />}
      {current === 'contact' && <Contact />}
      <footer className="mt-10 border-t border-neutral-200 dark:border-neutral-800">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-6 text-sm flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© {new Date().getFullYear()} Sourav Surya Majumder. All rights reserved.</p>
          <div className="flex items-center gap-4 text-xs text-neutral-600 dark:text-neutral-400">
            <span>Made with React & Tailwind</span>
            <a className="underline underline-offset-4" href="#contact" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' });}}>Back to top</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
