import React from 'react'
export function Button({ children, variant='default', size='md', className='', ...props }) {
  const base = 'inline-flex items-center justify-center font-medium transition-colors focus:outline-none disabled:opacity-50 disabled:pointer-events-none'
  const variants = {
    default: 'bg-neutral-900 text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-200',
    outline: 'border border-neutral-300 dark:border-neutral-700 bg-transparent hover:bg-neutral-100 dark:hover:bg-neutral-900',
    ghost: 'bg-transparent hover:bg-neutral-100 dark:hover:bg-neutral-900',
    secondary: 'bg-neutral-200 text-neutral-900 hover:bg-neutral-300 dark:bg-neutral-800 dark:text-neutral-100 dark:hover:bg-neutral-700'
  }
  const sizes = { sm: 'h-8 px-3 text-sm rounded-xl', md: 'h-10 px-4 rounded-2xl', lg: 'h-12 px-5 text-base rounded-2xl' }
  return (
    <button className={`${base} ${variants[variant]||variants.default} ${sizes[size]||sizes.md} ${className}`} {...props}>
      {children}
    </button>
  )
}
