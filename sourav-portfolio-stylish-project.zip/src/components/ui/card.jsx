import React from 'react'
export function Card({ children, className='' }) {
  return <div className={`border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 shadow-sm ${className}`}>{children}</div>
}
export function CardHeader({ children, className='' }) {
  return <div className={`p-4 border-b border-neutral-200 dark:border-neutral-800 ${className}`}>{children}</div>
}
export function CardTitle({ children, className='' }) {
  return <h3 className={`font-semibold ${className}`}>{children}</h3>
}
export function CardContent({ children, className='' }) {
  return <div className={`p-4 ${className}`}>{children}</div>
}
