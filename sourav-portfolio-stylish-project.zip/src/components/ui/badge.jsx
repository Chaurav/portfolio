import React from 'react'
export function Badge({ children, variant='default', className='' }) {
  const variants = {
    default: 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900',
    secondary: 'bg-neutral-200 text-neutral-900 dark:bg-neutral-800 dark:text-neutral-100',
    outline: 'border border-neutral-300 dark:border-neutral-700'
  }
  return <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${variants[variant]||variants.default} ${className}`}>{children}</span>
}
