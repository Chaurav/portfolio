import React from 'react'
export function Input({ className='', ...props }) {
  return <input className={`w-full border border-neutral-300 dark:border-neutral-700 rounded-xl px-3 py-2 bg-white dark:bg-neutral-950` + (className?` ${className}`:'')} {...props} />
}
